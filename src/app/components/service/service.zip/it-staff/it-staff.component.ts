import { Component } from '@angular/core';

@Component({
  selector: 'app-it-staff',
  templateUrl: './it-staff.component.html',
  styleUrls: ['./it-staff.component.css']
})
export class ItStaffComponent {

}
