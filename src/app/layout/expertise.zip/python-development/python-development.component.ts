import { Component } from '@angular/core';

@Component({
  selector: 'app-python-development',
  templateUrl: './python-development.component.html',
  styleUrls: ['./python-development.component.css']
})
export class PythonDevelopmentComponent {

}
