import { Component } from '@angular/core';

@Component({
  selector: 'app-saleforce',
  templateUrl: './saleforce.component.html',
  styleUrls: ['./saleforce.component.css']
})
export class SaleforceComponent {

}
