import { Component } from '@angular/core';

@Component({
  selector: 'app-microft-technologies',
  templateUrl: './microft-technologies.component.html',
  styleUrls: ['./microft-technologies.component.css']
})
export class MicroftTechnologiesComponent {

}
